var express = require('express');
var app = express();
var multer = require("multer");

app.post('/file_upload', multer({
  dest: './public',
  rename: function (fieldname, filename, req, res) {
    console.log("Rename...");
    return "hoge";
  }
}).single('file'), function (req, res) {
    // multerがpublic/配下にファイルを作成
    const filename = req.body.filename
    const content = fs.readFileSync(req.file.path, 'utf-8');
    res.send(filename + ': ' + content);
    // req.file.pathでmulterが作成したファイルのパスを取得可能
    //console.log(req.file.path, req.file.originalname);
    //res.end("upload!");
});

var server = app.listen(58080, function() {
    console.log("listening at port %s", server.address().port);
});
